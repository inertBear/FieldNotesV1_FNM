$( document ).ready(function(){
    alert('jQuery is working now, congrats!');
    
});